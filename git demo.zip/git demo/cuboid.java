package yt;

public class cuboid {
	int l,w,h;
	cuboid(int l,int w,int h){
		this.l=l;
		this.w=w;
		this.h=h;
		
	}
	cuboid(int l,int w){
		this.l=l;
		this.w=w;
		this.h=20;
		
	}
	cuboid(int dimension){
		l=dimension;
		w=dimension;
		h=dimension;
		
	}
	cuboid(){
		this.l=l;
		this.w=w;
		this.h=h;
	}
	public int volume() {
		return l*w*h;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int v;
		cuboid ob1=new cuboid(10,2,3);
		cuboid ob2=new cuboid(2,6);
		cuboid ob3=new cuboid(5);
		cuboid dob=new cuboid();
		
		v=ob1.volume();
		System.out.println(v);
		v=ob2.volume();
		System.out.println(v);
		v=ob3.volume();
		System.out.println(v);
		v=dob.volume();
		System.out.println(v);
		}
}
